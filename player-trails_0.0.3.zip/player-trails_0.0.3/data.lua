
local nyan_sprite = {
  type = "sprite",
  name = "player-trail",
  filename = "__player-trails__/glow.png",
  priority = "high",
  width = 820,
  height = 826,
  scale = 1/22,

}

data:extend({
  nyan_sprite
})
