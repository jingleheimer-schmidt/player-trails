
global = {}
-- game.print("migrated player-trails to 0.0.3")
