
global = {}
storage = {}
-- game.print("migrated player-trails to 0.0.4")
